﻿
namespace Vehicles_Extension.Factories
{
    public class VehicleFactory : IVehicleFactory
    {
        public VehicleFactory()
        {
        }
    }
}
