﻿
namespace Vehicles_Extension.Core
{
    using Models;

    public interface IEngine 
    {
        public void Start();
    }
}
