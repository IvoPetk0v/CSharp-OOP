﻿
namespace _1.Vehicles.Core
{
    public interface IEngine
    {
        public void Start();
    }
}
