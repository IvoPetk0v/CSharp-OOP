﻿
namespace _1.Vehicles.Factories
{
    public class VehicleFactory : IVehicleFactory
    {
        public VehicleFactory()
        {
        }
    }
}
