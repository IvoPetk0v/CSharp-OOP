﻿namespace Raiding.Factories
{
    class HeroFactory : IFactory
    {
        
    }
}
