﻿namespace Wild_Farm.Models.Foods
{
    public class Fruit : Food
    {
        public Fruit(int quantity) : base(quantity)
        {
        }
    }
}
