﻿
namespace Wild_Farm.Core.Interfaces
{
    interface IEngine
    {
        public void Start();
    }
}
