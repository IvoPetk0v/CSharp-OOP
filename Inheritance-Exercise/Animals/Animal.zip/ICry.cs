﻿namespace Animals
{
    public interface ICry
    {
        public  string ProduceSound();
    }
}
