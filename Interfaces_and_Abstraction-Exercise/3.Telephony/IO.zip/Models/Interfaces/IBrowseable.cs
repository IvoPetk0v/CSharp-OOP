﻿namespace Telephony.Models.Interfaces
{
    public interface IBrowseable
    {
        public string Browse(string url);
    }
}
