﻿
namespace _6.Food_Shortage.Interfacces
{
    public interface IBuyer
    {
        public int Food { get; set; }
        public void BuyFood();
       
    }
}
