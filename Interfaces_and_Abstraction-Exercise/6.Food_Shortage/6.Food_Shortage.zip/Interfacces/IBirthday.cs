﻿namespace Birthday_Celebrations
{
    public interface IBirthday
    {
        public string Birthday { get; }
    }
}
